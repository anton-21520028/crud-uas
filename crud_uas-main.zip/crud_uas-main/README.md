# TUGAS UAS PPB3 CRUD REACT NATIVE API

API ENDPOINT:
Mobil:
   - List Data: https://6394c1c14df9248eadabf031.mockapi.io/api/mobil (GET)
   - Detail : https://6394c1c14df9248eadabf031.mockapi.io/api/mobil/:id (GET)
   - Tambah: https://6394c1c14df9248eadabf031.mockapi.io/api/mobil (POST)
   - Edit: https://6394c1c14df9248eadabf031.mockapi.io/api/mobil/:id (PUT)
   - Hapus: https://6394c1c14df9248eadabf031.mockapi.io/api/mobil/:id (DELETE)
   
   
   
 CARA INSTALL
 1. Clone project dengan di git bash dengan perintah "git clone https://github.com/muzakisyahrul/crud_uas.git"
 2. Masuk folder yang sudah di clone.
 3. Lalu buka cmd ketik "npm install"
 4. RUN ANDROID dengan perintah "npx react-native run-android"
 
