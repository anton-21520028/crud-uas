export default {
    BASE_URL: 'https://6394c1c14df9248eadabf031.mockapi.io/api/',
};